package com.ziidi.prince

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Vibrator
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

fun String.has(vararg w: String) = w.any { contains(it) }

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var micBtn: Button
    private lateinit var tts: TextToSpeech
    private var sr: SpeechRecognizer? = null
    private val langs = arrayOf("ur-PK", "hi-IN", "en-US")
    private var li = 0
    private var torchOn = false
    private val jokes = listOf(
        "Teacher: Late kyun aaye? Student: Sign board par likha tha School ahead, go slow.",
        "Mobile ne kaha charge karo warna band ho jaunga. Insan ne kaha, main bhi 1% par chalta hoon.",
        "Doctor: Aap ko aaram chahiye. Mareez: Biwi kehti hai kaam karo. Doctor: Phir biwi ko bhi aaram dein.")
    private var jokeI = 0

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val bg = Color.parseColor("#030b14"); val cy = Color.parseColor("#22d3ee")
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(32, 80, 32, 32) }
        root.addView(TextView(this).apply { text = "ZIIDI PRINCE"; textSize = 22f; setTextColor(cy); letterSpacing = 0.14f })
        logView = TextView(this).apply { setTextColor(Color.parseColor("#e6f4fb")); textSize = 16f; setPadding(0, 24, 0, 24) }
        scroll = ScrollView(this).apply { addView(logView) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "Likho ya bolo..."; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT; imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, _, _ -> send(); true }
        }
        val langBtn = Button(this).apply { text = "UR"; setOnClickListener { li = (li + 1) % 3; text = arrayOf("UR", "HI", "EN")[li] } }
        micBtn = Button(this).apply { text = "🎤"; setOnClickListener { listen() } }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(langBtn); row.addView(micBtn)
        root.addView(row)
        setContentView(root)
        tts = TextToSpeech(this, this)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS), 1)
        say("ZIIDI", "Salam! Mic dabayein aur boliye. Misaal: torch on, volume badhao, ali ko call karo, open whatsapp, alarm 7 baje.")
    }

    override fun onInit(s: Int) { tts.language = Locale("hi", "IN") }

    private fun send() { val t = input.text.toString().trim(); input.setText(""); if (t.isNotEmpty()) handle(t) }

    private fun say(who: String, t: String) {
        logView.append("$who: $t\n\n"); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        if (who == "ZIIDI") tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "z")
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { say("ZIIDI", "Mic ki ijazat dein."); return }
        sr?.destroy(); sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle?) { micBtn.text = "🎤"; r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { handle(it) } }
            override fun onError(e: Int) { micBtn.text = "🎤"; say("ZIIDI", "Samajh nahi aaya, dobara boliye.") }
            override fun onReadyForSpeech(p: Bundle?) { micBtn.text = "..." }
            override fun onBeginningOfSpeech() {}; override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}; override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}; override fun onEvent(t: Int, p: Bundle?) {}
        })
        sr?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_LANGUAGE, langs[li]))
    }

    private fun go(i: Intent) { try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { say("ZIIDI", "Ye kaam nahi ho saka.") } }

    private fun handle(raw: String) {
        say("Aap", raw)
        val t = raw.lowercase().trim()
        val nums = Regex("\\d+").findAll(t).map { it.value.toInt() }.toList()
        when {
            t.has("torch", "flash", "batti", "light") -> torch(!t.has("off", "band", "bujha"))
            t.has("volume", "awaz", "sound") -> volume(t)
            t.has("wifi", "wi-fi", "internet") -> { say("ZIIDI", "WiFi panel khol raha hoon."); go(Intent(Settings.Panel.ACTION_WIFI)) }
            t.has("bluetooth") -> { say("ZIIDI", "Bluetooth settings khol raha hoon."); go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
            t.has("setting") -> go(Intent(Settings.ACTION_SETTINGS))
            t.has("battery") -> { val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager; say("ZIIDI", "Battery ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}% hai.") }
            t.has("time", "waqt", "baje kya") && !t.has("alarm") -> say("ZIIDI", "Abhi " + SimpleDateFormat("h:mm a", Locale.US).format(Date()) + " hain.")
            t.has("date", "tareekh", "aaj kya din") -> say("ZIIDI", "Aaj " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.US).format(Date()) + " hai.")
            t.has("alarm") && nums.isNotEmpty() -> {
                var h = nums[0]; val m = nums.getOrElse(1) { 0 }; if (t.has("pm", "sham", "raat", "dopahar") && h < 12) h += 12
                say("ZIIDI", "Alarm set: $h:${m.toString().padStart(2, '0')}")
                go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            }
            t.has("timer") && nums.isNotEmpty() -> {
                val sec = if (t.has("second", "sec")) nums[0] else if (t.has("ghant", "hour")) nums[0] * 3600 else nums[0] * 60
                say("ZIIDI", "Timer set ho gaya."); go(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, sec).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            }
            t.has("camera", "photo", "tasveer", "selfie") -> go(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
            t.has("vibrate") -> { (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).vibrate(400); say("ZIIDI", "Vibrate.") }
            t.has("joke", "lateefa", "latifa") -> say("ZIIDI", jokes[jokeI++ % jokes.size])
            t.has("call", "phone laga", "dial") -> call(t)
            t.has("sms", "message bhej", "msg") -> sms(t)
            t.has("play", "gana", "song", "naat", "youtube") && !t.has("open", "kholo") -> {
                val q = clean(t, "play", "gana", "song", "naat", "youtube", "par", "pe", "sunao", "chalao", "lagao", "karo")
                say("ZIIDI", "YouTube par $q"); go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
            }
            t.has("map", "rasta", "navigate", "qareeb") -> {
                val q = clean(t, "map", "maps", "rasta", "navigate", "qareeb", "dikhao", "batao", "karo", "to", "ka", "ki")
                say("ZIIDI", "Maps: $q"); go(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q))))
            }
            t.has("open", "kholo", "khol", "chalao", "launch", "start") -> openApp(t)
            else -> { say("ZIIDI", "Google par dhoond raha hoon."); go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(t)))) }
        }
    }

    private fun clean(t: String, vararg w: String): String {
        var s = " $t "; w.forEach { s = s.replace(Regex("\\b$it\\b"), " ") }; return s.replace(Regex("\\s+"), " ").trim()
    }

    private fun torch(on: Boolean) {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            cm.setTorchMode(id, on); torchOn = on; say("ZIIDI", if (on) "Torch on kar di." else "Torch band kar di.")
        } catch (e: Exception) { say("ZIIDI", "Torch nahi chal saki.") }
    }

    private fun volume(t: String) {
        val a = getSystemService(Context.AUDIO_SERVICE) as AudioManager; val s = AudioManager.STREAM_MUSIC
        when {
            t.has("mute", "khamosh", "zero") -> a.setStreamVolume(s, 0, AudioManager.FLAG_SHOW_UI)
            t.has("full", "max", "poori") -> a.setStreamVolume(s, a.getStreamMaxVolume(s), AudioManager.FLAG_SHOW_UI)
            t.has("kam", "down", "low", "ghata", "decrease") -> repeat(3) { a.adjustStreamVolume(s, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }
            else -> repeat(3) { a.adjustStreamVolume(s, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }
        }
        say("ZIIDI", "Volume theek kar diya.")
    }

    private fun findContact(name: String): String? {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    private fun target(t: String, vararg w: String): Pair<String, String> {
        val n = Regex("\\+?\\d[\\d\\s-]{6,}\\d").find(t)?.value?.replace(Regex("[\\s-]"), "")
        val name = clean(t, *w, "ko", "karo", "kro", "lagao", "mila", "ka", "number", "se", "bhejo", "likho", "ki")
        return Pair(n ?: findContact(name) ?: "", name)
    }

    private fun call(t: String) {
        val (num, name) = target(t, "call", "phone", "dial")
        if (num.isEmpty()) { say("ZIIDI", "\"$name\" contacts mein nahi mila."); return }
        say("ZIIDI", "$name ko call laga raha hoon.")
        val ok = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        go(Intent(if (ok) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num))))
    }

    private fun sms(t: String) {
        val (num, name) = target(t, "sms", "message", "msg", "send")
        say("ZIIDI", "SMS screen khol raha hoon.")
        go(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(num))))
    }

    private fun openApp(t: String) {
        val alias = mapOf("fb" to "facebook", "insta" to "instagram", "wa" to "whatsapp", "yt" to "youtube", "tik tok" to "tiktok", "map" to "maps")
        var n = clean(t, "open", "kholo", "khol", "chalao", "launch", "start", "karo", "kro", "app", "ko")
        n = alias[n] ?: n
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
        if (hit != null && n.isNotEmpty()) { say("ZIIDI", "$n khol raha hoon."); go(pm.getLaunchIntentForPackage(hit.activityInfo.packageName)!!) }
        else say("ZIIDI", "\"$n\" naam ki app nahi mili.")
    }

    override fun onDestroy() { sr?.destroy(); tts.shutdown(); super.onDestroy() }
}
